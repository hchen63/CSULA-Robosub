SparkFun TLC5940 Libraries
=================================

Libraries for use in different environments. 

Directory Contents
-------------------
* **/Arduino** - [Arduino IDE](http://www.arduino.cc/en/Main/Software) libraries


Update Library Instructions:
----------------------------
To get the most up-to-date version of the library, you must run the following git subtree commands. 

$git subtree pull -P Libraries/Arduino --squash https://github.com/sparkfun/SparkFun_TLC5940_Arduino_Library.git master
